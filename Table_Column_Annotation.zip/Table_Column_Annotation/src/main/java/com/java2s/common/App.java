package com.java2s.common;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

  public static void main(String[] args) {
    ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
        "applicationContext.xml");
    PersonDaoImpl dao = (PersonDaoImpl) context.getBean("personDao");

    Person p1 = new Person("Tom", "Smith");
    p1.setId(1L);
    Person p2 = new Person("Jack", "Kook");
    p2.setId(2L);
    
    dao.save(p1);
    dao.save(p2);

    List<Person> persons = dao.getAll();
    for (Person person : persons) {
      System.out.println(person);
    }

    context.close();
    
    Helper.checkData();
  }
}
